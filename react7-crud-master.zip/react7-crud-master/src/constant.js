export const url = "http://localhost:3001";

export const getData = "/posts";
export const postData = "/posts";
export const deleteData = "/posts/"; //+id
export const updateData = "/posts";
